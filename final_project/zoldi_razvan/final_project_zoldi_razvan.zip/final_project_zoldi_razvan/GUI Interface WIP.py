import tkinter as tk
from tkinter import ttk
from application import *
from tkinter import filedialog


class OringGUI():
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("O-ring calculator (work in progress)")
        self.create_widgets()
        # imagefile = "O-ring small 2.png"
        # self.window.im1 = Image.open(imagefile)
        self.radio_variable = tk.StringVar()
        self.combobox_value = tk.StringVar()

    def create_widgets(self):
        # Create some room around all the internal frames
        self.window['padx'] = 5
        self.window['pady'] = 5

        # - - - - - - - - - - - - - - - - - - - - -

        # The Inputs frame
        # oring_frame = ttk.LabelFrame(self.window, text="Commands", padx=5, pady=5, relief=tk.RIDGE)
        inputs = ttk.LabelFrame(self.window, text="Inputs", relief=tk.RIDGE)
        inputs.grid(row=1, column=1, sticky=tk.E + tk.W + tk.N + tk.S)

        # The Oring frame
        oring = ttk.LabelFrame(inputs, text="O-ring characteristics", relief=tk.RIDGE)
        oring.grid(row=1, column=1, sticky=tk.E + tk.W + tk.N + tk.S)
        # The Bore frame
        bore = ttk.LabelFrame(inputs, text="Bore characteristics", relief=tk.RIDGE)
        bore.grid(row=2, column=1, sticky=tk.E + tk.W + tk.N + tk.S)
        # The Piston frame
        piston = ttk.LabelFrame(inputs, text="Piston characteristics", relief=tk.RIDGE)
        piston.grid(row=3, column=1, sticky=tk.E + tk.W + tk.N + tk.S)

        # o-ring fields
        # Characteristics

        # code
        oring_name = ttk.Label(oring, text="O-ring code")
        oring_name.grid(row=1, column=1, sticky=tk.W + tk.N)
        oring_name_entry = ttk.Entry(oring, width=10)
        oring_name_entry.grid(row=1, column=2, sticky=tk.W, pady=3)

        # Inner diameter d1
        oring_d1 = ttk.Label(oring, text="Inner diam. Ød1          ")
        oring_d1.grid(row=2, column=1, sticky=tk.W + tk.N)
        oring_d1_entry = ttk.Entry(oring, width=10)
        oring_d1_entry.grid(row=2, column=2, sticky=tk.W, pady=3)

        # Inner diam d1 tolerance
        oring_d1_tol = ttk.Label(oring, text="Inner diam. tol ±          ")
        oring_d1_tol.grid(row=3, column=1, sticky=tk.W + tk.N)
        oring_d1_tol_entry = ttk.Entry(oring, width=10)
        oring_d1_tol_entry.grid(row=3, column=2, sticky=tk.W, pady=3)

        # Oring d2
        oring_d2 = ttk.Label(oring, text="Section Ød2          ")
        oring_d2.grid(row=4, column=1, sticky=tk.W + tk.N)
        oring_d2_entry = ttk.Entry(oring, width=10)
        oring_d2_entry.grid(row=4, column=2, sticky=tk.W, pady=3)

        # Cross section diam tolerance
        oring_d2_tol = ttk.Label(oring, text="Section tol. ±          ")
        oring_d2_tol.grid(row=5, column=1, sticky=tk.W + tk.N)
        oring_d2_tol_entry = ttk.Entry(oring, width=10)
        oring_d2_tol_entry.grid(row=5, column=2, sticky=tk.W, pady=3)

        # Material
        oring_material = ttk.Label(oring, text="Material          ")
        oring_material.grid(row=6, column=1, sticky=tk.W + tk.N)
        oring_material_entry = ttk.Entry(oring, width=10)
        oring_material_entry.grid(row=6, column=2, sticky=tk.W, pady=3)

        # oring1 = ORing(oring_name_entry,
        #                {'inner_diam Ød1': oring_d1_entry,
        #                 'inner_diam_tol ±': oring_d1_tol_entry,
        #                 'section Ød2': oring_d2_entry,
        #                 'section_tol ±': oring_d2_tol_entry,
        #                 'material': oring_material_entry})

        # Bore
        # Internal diam tolerance
        bore_d4 = ttk.Label(bore, text="Internal diam. Ød4      ")
        bore_d4.grid(row=1, column=1, sticky=tk.W + tk.N)
        bore_d4_entry = ttk.Entry(bore, width=10)
        bore_d4_entry.grid(row=1, column=2, sticky=tk.W, pady=3)
        # Bore tolerance combobox
        combobox_label = tk.Label(bore, text="Internal Ød4 tol")
        combobox_label.grid(row=2, column=1, sticky=tk.W + tk.N)

        self.combobox_value = tk.StringVar()
        d4_combobox = ttk.Combobox(bore, height=4, textvariable=self.combobox_value, width=7)
        d4_combobox.grid(row=2, column=2)
        d4_combobox['values'] = ("F7", "F8", "G6", "G7", "H6", "H7", "H8", "H9", "H11")
        d4_combobox.current(0)

        # bore1 = Bore(bore_d4_entry, d4_combobox)

        #  Piston
        # Piston diameter d9
        piston_d9 = ttk.Label(piston, text="Piston diam. Ød9        ")
        piston_d9.grid(row=1, column=1, sticky=tk.W + tk.N)
        piston_d9_entry = ttk.Entry(piston, width=10)
        piston_d9_entry.grid(row=1, column=2, sticky=tk.W, pady=3)
        # Piston diameter d9 tolerance combobox
        combobox_label = tk.Label(piston, text="Piston Ød9 tol")
        combobox_label.grid(row=2, column=1, sticky=tk.W + tk.N)

        self.combobox_value = tk.StringVar()
        d9_combobox = ttk.Combobox(piston, height=4, textvariable=self.combobox_value, width=7)
        d9_combobox.grid(row=2, column=2)
        d9_combobox['values'] = ("f7", "f8", "g6", "g7", "h6", "h7", "h8", "h9", "h11")
        d9_combobox.current(0)

        # Groove diameter d3
        groove_d3 = ttk.Label(piston, text="Piston diam. Ød9        ")
        groove_d3.grid(row=3, column=1, sticky=tk.W + tk.N)
        groove_d3_entry = ttk.Entry(piston, width=10)
        groove_d3_entry.grid(row=3, column=2, sticky=tk.W, pady=3)
        # Groove diameter d3 tolerance combobox
        combobox_label = tk.Label(piston, text="Piston Ød9 tol")
        combobox_label.grid(row=4, column=1, sticky=tk.W + tk.N)

        self.combobox_value = tk.StringVar()
        d3_combobox = ttk.Combobox(piston, height=4, textvariable=self.combobox_value, width=7)
        d3_combobox.grid(row=4, column=2)
        d3_combobox['values'] = ("f7", "f8", "g6", "g7", "h6", "h7", "h8", "h9", "h11")
        d3_combobox.current(0)

        # Groove width b
        groove_b = ttk.Label(piston, text="Groove width b        ")
        groove_b.grid(row=5, column=1, sticky=tk.W + tk.N)
        groove_b_entry = ttk.Entry(piston, width=10)
        groove_b_entry.grid(row=5, column=2, sticky=tk.W, pady=3)
        # Groove radius
        groove_r = ttk.Label(piston, text="Groove radius r        ")
        groove_r.grid(row=6, column=1, sticky=tk.W + tk.N)
        groove_r_entry = ttk.Entry(piston, width=10)
        groove_r_entry.grid(row=6, column=2, sticky=tk.W, pady=3)

        # piston1 = Piston({'piston diameter Ød9': piston_d9_entry,
        #                   'Ød9 tol': d9_combobox,
        #                   'groove Ød3': groove_d3_entry,
        #                   'Ød3 tol': d3_combobox,
        #                   'groove width b': groove_b_entry,
        #                   'groove radius r': groove_r_entry})

        # - - - - - - - - - - - - - - - - - - - - -
        # Schematic frame
        schematic_frame = ttk.LabelFrame(self.window, text="Schematic",
                                         relief=tk.RIDGE)
        schematic_frame.grid(row=1, column=2, sticky=tk.E + tk.W + tk.N + tk.S)
        schematic = ttk.Label(schematic_frame, text="Schematic of O-ring assembly        ")
        schematic.grid(row=1, column=1, sticky=tk.W + tk.N + tk.N)
        photo = tk.PhotoImage(file="O-ring GUI.png")
        label = tk.Label(schematic_frame, image=photo)
        label.image = photo
        label.place(x=0, y=0)

        # - - - - - - - - - - - - - - - - - - - - -
        # - - - - - - - - - - - - - - - - - - - - -
        # Run button in the lower right corner
        quit_button = tk.Button(self.window, text="Run", command=self.window.destroy, fg='cyan', bg='gray')
        quit_button.grid(row=1, column=3)

        # Quit button in the lower right corner
        quit_button = tk.Button(self.window, text="Quit", command=self.window.destroy, bg='orange')
        quit_button.grid(row=2, column=3)


# Create the entire GUI program
program = OringGUI()

# Start the GUI event loop
program.window.mainloop()
