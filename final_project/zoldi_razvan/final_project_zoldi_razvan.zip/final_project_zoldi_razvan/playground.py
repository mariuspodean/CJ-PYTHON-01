from application import *


multiply = 50

# ******** Creating O-ring *************
# print('*' * multiply)

oring1 = ORing('2-208', {'inner_diam Ød1': 15.470, 'inner_diam_tol ±': 0.230, 'section Ød2': 3.53, 'section_tol ±': 0.1,
                         'material': 'NBR'})
oring2 = ORing('2-210', {'inner_diam Ød1': 18.640, 'inner_diam_tol ±': 0.250, 'section Ød2': 3.53, 'section_tol ±': 0.1,
                         'material': 'NBR'})
oring3 = ORing('2-212', {'inner_diam Ød1': 21.820, 'inner_diam_tol ±': 0.280, 'section Ød2': 3.53, 'section_tol ±': 0.1,
                         'material': 'NBR'})
# print(oring1)
# diam = ORing.inner_diam(oring1)
# d1_max = oring1.inner_diam()
# print('-' * multiply)
# print(d1_max)
# cross_sect = ORing.cross_section(oring1)
# cross_sect2 = ORing.dancilus(oring1)
# print(repr(oring1))
# print(diam)
# print(cross_sect[0])
# print(cross_sect2[1])
# print(ORing.circle_area(10))
# print('-' * multiply)
# print()

# ******* Creating Bore *****************
# print('*' * multiply)
bore1 = Bore(21.41, 'H8')
bore2 = Bore(24.67, 'H8')
bore3 = Bore(27.91, 'H8')
# bore1.calculate_diameters_bore()
# print(bore1)
# print(repr(bore1))
# print('-' * multiply)
# print()


# ******* Creating Piston *****************
# print('*' * multiply)
# piston1 = Piston({'piston diameter Ød9': 21.410, 'Ød9 tol': 'f7',
#                   'groove Ød3': 16.06, 'Ød3 tol': 'h9', 'groove width b': 5, 'groove radius r': 0.6})
piston1 = Piston({'piston diameter Ød9': 21.410, 'Ød9 tol': 'f7',
                  'groove Ød3': 16.06, 'Ød3 tol': 'h9', 'groove width b': 5, 'groove radius r': 0.6})
piston2 = Piston({'piston diameter Ød9': 24.670, 'Ød9 tol': 'f7',
                  'groove Ød3': 19.320, 'Ød3 tol': 'h9', 'groove width b': 5, 'groove radius r': 0.6})
piston3 = Piston({'piston diameter Ød9': 27.910, 'Ød9 tol': 'f7',
                  'groove Ød3': 22.640, 'Ød3 tol': 'h9', 'groove width b': 5, 'groove radius r': 0.6})

# piston_diam = Piston.calculate_diameter_piston(piston1)
# piston_groove_diam = Piston.calculate_diameter_groove(piston1)
# piston_groove_width = Piston.calculate_groove_width(piston1)
# piston_groove_radius = Piston.calculate_groove_radius(piston1)
# print(piston1)
# print(piston_diam)
# print(piston_groove_diam)
# print(piston_groove_width)
# print(piston_groove_radius)
# print('-' * multiply)
# print()


# ******* Creating Studies  *****************
# print('*' * multiply)
study_1 = OringStudy('Blue Project', oring1, bore1, piston1)
study_2 = OringStudy('Red Project', oring2, bore2, piston2)
study_3 = OringStudy('Green Project', oring3, bore3, piston3)
print(study_1)


# print('*' * multiply)
# print('*' * multiply)
# print(study_2)


# *********** Multiple Studies / Same Product *************
# print('*' * multiply)
# studies_list = ProductStudies(study_1, study_3)
# print(studies_list.__getitem__(0))
# studies_list.__delitem__(0)
# studies_list.append(study_1)
# studies_list.__iter__()
# print(studies_list.__len__())
# studies_list.append(study_1)
# studies_list.remove(study_1)
# studies_list.pop()
# print(studies_list)


# def to_overloading():
#     pressure_1 = Pressure(100)
#     pressure_2 = Pressure(50)
#     total_pressure = pressure_1 + pressure_2
#     return total_pressure
#
#
# print(to_overloading())
#
# pressure_3 = Pressure(10)
# pressure_4 = Pressure(20)
# total_pressure = pressure_3 + pressure_4
# print(total_pressure)
