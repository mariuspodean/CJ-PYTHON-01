# for plotting
import pandas as pd


class Hole:

    def __init__(self, nominal_diameter, tolerance):
        self.nominal_diameter = nominal_diameter
        self.tolerance = tolerance
        # parse through excel sheet to populate tol grades list
        df = pd.ExcelFile('external resources.xls').parse('plot')
        grade_h = df['grade H'].tolist()
        self.grade_h = grade_h
        self.cleaned_list_size = [x for x in self.grade_h if str(x) != 'nan']
        # check if tolerance grade desired is present in out list
        if tolerance not in self.cleaned_list_size:
            raise KeyError(f'Desired tolerance is not recommended for Bore Diameter Ød4 = {nominal_diameter}')
        elif type(nominal_diameter) != float:
            raise ValueError('Bore diameter Ød4 should be float type')
        elif type(tolerance) != str:
            raise ValueError('Bore  diameter Ød3 tolerance should be string type; example "H8"')
        self.diam_max = None
        self.diam_min = None

    def calculate_diameters_bore(self):
        df1 = pd.read_excel('external resources.xls', sheet_name='holes (2)')
        df2 = df1.set_index("tol", drop=True)
        interval = ''
        if 3 < self.nominal_diameter <= 6:
            interval = '3 TO 6'
        elif 6 < self.nominal_diameter <= 10:
            interval = '6 TO 10'
        elif 10 < self.nominal_diameter <= 18:
            interval = '10 TO 18'
        elif 18 < self.nominal_diameter <= 30:
            interval = '18 TO 30'
        elif 30 < self.nominal_diameter <= 50:
            interval = '30 TO 50'
        elif 50 < self.nominal_diameter <= 80:
            interval = '50 TO 80'
        elif 80 < self.nominal_diameter <= 120:
            interval = '80 TO 120'
        elif 120 < self.nominal_diameter <= 180:
            interval = '120 TO 180'
        elif 180 < self.nominal_diameter <= 250:
            interval = '180 TO 250'
        elif 250 < self.nominal_diameter <= 315:
            interval = '250 TO 315'
        elif 315 < self.nominal_diameter <= 400:
            interval = '315 TO 400'
        tol_max_str = f'{self.tolerance}_max'
        tol_min_str = f'{self.tolerance}_min'
        df3 = df2.loc[tol_max_str:tol_min_str, interval:interval]
        tol_max = df3.loc[tol_max_str, interval]
        tol_min = df3.loc[tol_min_str, interval]
        diam_max = self.nominal_diameter + tol_max
        diam_min = self.nominal_diameter + tol_min
        self.diam_min = diam_min
        self.diam_max = diam_max
        # list1 = [diam_max, diam_min]
        return self.diam_max, self.diam_min

    def __str__(self):
        return f'\nBore internal diameter Ød4 - {self.nominal_diameter} with {self.tolerance} tol.' \
               f'\n\n MAX: {"{:.3f}".format(self.diam_max)}   MIN:  {"{:.3f}".format(self.diam_min)}  [mm]'


class Shaft:

    def __init__(self, piston_diameter, piston_diam_tol, groove_diameter, groove_diam_tol):
        self.piston_diameter = piston_diameter
        self.piston_diam_tol = piston_diam_tol
        self.groove_diameter = groove_diameter
        self.groove_diam_tol = groove_diam_tol
        # parse through excel sheet to populate tol grades list
        df = pd.ExcelFile('external resources.xls').parse('plot')
        grade_s = df['grade S'].tolist()
        self.grade_s = grade_s
        self.cleaned_list_size2 = [x for x in self.grade_s if str(x) != 'nan']
        # check if piston_diam_tol grade desired is present in out list
        if piston_diam_tol and groove_diam_tol not in self.cleaned_list_size2:
            raise KeyError(f'Desired {self.piston_diam_tol} / {groove_diam_tol} is not recommended for '
                           f'Shaft/ Groove Diameter ød9 / ød3 = {piston_diameter} / {piston_diameter}')

    def calculate_diameter_piston(self):
        df1 = pd.read_excel('external resources.xls', sheet_name='shafts (2)')
        df2 = df1.set_index("tol", drop=True)
        interval = ''
        if 3 < self.piston_diameter <= 6:
            interval = '3 TO 6'
        elif 6 < self.piston_diameter <= 10:
            interval = '6 TO 10'
        elif 10 < self.piston_diameter <= 18:
            interval = '10 TO 18'
        elif 18 < self.piston_diameter <= 30:
            interval = '18 TO 30'
        elif 30 < self.piston_diameter <= 50:
            interval = '30 TO 50'
        elif 50 < self.piston_diameter <= 80:
            interval = '50 TO 80'
        elif 80 < self.piston_diameter <= 120:
            interval = '80 TO 120'
        elif 120 < self.piston_diameter <= 180:
            interval = '120 TO 180'
        elif 180 < self.piston_diameter <= 250:
            interval = '180 TO 250'
        elif 250 < self.piston_diameter <= 315:
            interval = '250 TO 315'
        elif 315 < self.piston_diameter <= 400:
            interval = '315 TO 400'
        tol_max_str = f'{self.piston_diam_tol}_max'
        tol_min_str = f'{self.piston_diam_tol}_min'
        df3 = df2.loc[tol_max_str:tol_min_str, interval:interval]
        tol_max = df3.loc[tol_max_str, interval]
        tol_min = df3.loc[tol_min_str, interval]
        piston_diam_max = self.piston_diameter + tol_max
        piston_diam_min = self.piston_diameter + tol_min
        # list1 = [diam_max, diam_min]
        return piston_diam_max, piston_diam_min

    def calculate_diameter_groove(self):
        df1 = pd.read_excel('external resources.xls', sheet_name='shafts (2)')
        df2 = df1.set_index("tol", drop=True)
        interval = ''
        if 3 < self.groove_diameter <= 6:
            interval = '3 TO 6'
        elif 6 < self.groove_diameter <= 10:
            interval = '6 TO 10'
        elif 10 < self.groove_diameter <= 18:
            interval = '10 TO 18'
        elif 18 < self.groove_diameter <= 30:
            interval = '18 TO 30'
        elif 30 < self.groove_diameter <= 50:
            interval = '30 TO 50'
        elif 50 < self.groove_diameter <= 80:
            interval = '50 TO 80'
        elif 80 < self.groove_diameter <= 120:
            interval = '80 TO 120'
        elif 120 < self.groove_diameter <= 180:
            interval = '120 TO 180'
        elif 180 < self.groove_diameter <= 250:
            interval = '180 TO 250'
        elif 250 < self.groove_diameter <= 315:
            interval = '250 TO 315'
        elif 315 < self.groove_diameter <= 400:
            interval = '315 TO 400'
        tol_max_str = f'{self.groove_diam_tol}_max'
        tol_min_str = f'{self.groove_diam_tol}_min'
        df3 = df2.loc[tol_max_str:tol_min_str, interval:interval]
        tol_max = df3.loc[tol_max_str, interval]
        tol_min = df3.loc[tol_min_str, interval]
        groove_diam_max = self.groove_diameter + tol_max
        groove_diam_min = self.groove_diameter + tol_min
        # list1 = [diam_max, diam_min]
        return groove_diam_max, groove_diam_min

    def __str__(self):
        return f'Shaft piston diameter ød9 - {self.piston_diameter} with {self.piston_diam_tol} tol.\n' \
               f'Shaft groove diam ød3 - {self.groove_diameter} with {self.groove_diam_tol} tol.'


