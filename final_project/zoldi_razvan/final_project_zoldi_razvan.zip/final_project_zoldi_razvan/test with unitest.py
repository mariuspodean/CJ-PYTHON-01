import unittest
from application import ORing, Bore, Piston


class TestOring(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("start O-Ring test")

    @classmethod
    def tearDownClass(cls):
        print("end O-Ring test")

    def test_inner_diam(self):
        test_oring1 = ORing('2-208', {'inner_diam Ød1': 15.470,
                                      'inner_diam_tol ±': 0.230,
                                      'section Ød2': 3.53,
                                      'section_tol ±': 0.1,
                                      'material': 'NBR'})
        test_inner = ORing.inner_diam(test_oring1)
        d1_max = round(test_inner[0], 2)
        d1_min = round(test_inner[1], 2)

        self.assertEqual(d1_max, 15.70), 'Class O-ring def inner diam do not ' \
                                         'perform calculation for d1_max properly'
        self.assertEqual(d1_min, 15.24), 'Class O-ring def inner diam do not ' \
                                         'perform calculation for d1_min properly'

    def test_cross_section(self):
        test_oring1 = ORing('2-208', {'inner_diam Ød1': 15.470,
                                      'inner_diam_tol ±': 0.230,
                                      'section Ød2': 3.53,
                                      'section_tol ±': 0.1,
                                      'material': 'NBR'})
        test_cross_section = ORing.cross_section(test_oring1)
        d2_max = round(test_cross_section[0], 2)
        d2_min = round(test_cross_section[1], 2)

        self.assertEqual(d2_max, 3.63), 'Class O-ring def cross_section do not ' \
                                        'perform calculation for d2_max properly'
        self.assertEqual(d2_min, 3.43), 'Class O-ring def cross_section do not ' \
                                        'perform calculation for d2_min properly'

    def test_dancilus(self):
        test_oring1 = ORing('2-208', {'inner_diam Ød1': 15.470,
                                      'inner_diam_tol ±': 0.230,
                                      'section Ød2': 3.53,
                                      'section_tol ±': 0.1,
                                      'material': 'NBR'})
        test_dancilus = ORing.dancilus(test_oring1)
        oring_csa_max = round(test_dancilus[1], 3)
        oring_csa_min = round(test_dancilus[0], 3)

        self.assertEqual(oring_csa_max, 9.240), 'Class O-ring def dancilus do not ' \
                                                'perform calculation for oring_csa_max properly'
        self.assertEqual(oring_csa_min, 10.349), 'Class O-ring def dancilus do not ' \
                                                 'perform calculation for oring_csa_max properly'

    def test_circle_area(self):
        test_diameter = 10
        test_circle_area = ORing.circle_area(test_diameter)

        result_diameter = round(test_circle_area, 2)

        self.assertEqual(result_diameter, 78.54), 'Class O-ring def circle_area do not ' \
                                                  'perform calculation for circle area properly'


class TestBore(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("start Bore test")

    @classmethod
    def tearDownClass(cls):
        print("end Bore test")

    def test_bore_init(self):
        # bore1 = Bore(1.5, 'H8')  # choose a smaller diameter that 3 to check exception
        bore1 = Bore(21.41, 'H8')
        self.assertRaises(Exception)

    def test_bore_calculation(self):
        bore1 = Bore(21.41, 'H8')

        test_bore = Bore.calculate_diameters_bore(bore1)
        d4_max = round(test_bore[0], 3)
        d4_min = round(test_bore[1], 3)

        self.assertEqual(d4_max, 21.443), 'Class Bore def bore_calculation do not ' \
                                          'perform calculation for bore diameter d4_max properly'
        self.assertEqual(d4_min, 21.410), 'Class Bore def bore_calculation do not ' \
                                          'perform calculation for bore diameter d4_min properly'


class TestPiston(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print("start Piston test")

    @classmethod
    def tearDownClass(cls):
        print("end Piston test")

    def test_piston_init(self):
        # test_piston1 = Piston({'piston diameter Ød9': 21.410,
        #                        'Ød9 tol': 'f7',
        #                        'groove Ød3': 16.06,
        #                        'Ød3 tol': 'h9',
        #                        'groove width b': 5})  # remove one parameter of piston for testing purpose

        test_piston1 = Piston({'piston diameter Ød9': 21.410,
                               'Ød9 tol': 'f7',
                               'groove Ød3': 16.06,
                               'Ød3 tol': 'h9',
                               'groove width b': 5,
                               'groove radius r': 0.6})
        self.assertRaises(KeyError)

    def test_calculate_groove_width(self):
        test_piston1 = Piston({'piston diameter Ød9': 21.410,
                               'Ød9 tol': 'f7',
                               'groove Ød3': 16.06,
                               'Ød3 tol': 'h9',
                               'groove width b': 5,
                               'groove radius r': 0.6})
        test_groove_width = Piston.calculate_groove_width(test_piston1)
        b_max = round(test_groove_width[0], 1)
        b_min = round(test_groove_width[1], 1)

        self.assertEqual(b_max, 5.2), 'Class Piston def calculate_groove_width do not ' \
                                      'perform calculation for piston groove b max properly'
        self.assertEqual(b_min, 5.0), 'Class Piston def calculate_groove_width do not ' \
                                      'perform calculation for piston groove b min properly'

    def test_calculate_groove_radius(self):
        test_piston1 = Piston({'piston diameter Ød9': 21.410,
                               'Ød9 tol': 'f7',
                               'groove Ød3': 16.06,
                               'Ød3 tol': 'h9',
                               'groove width b': 5,
                               'groove radius r': 0.6})
        test_groove_radius = Piston.calculate_groove_radius(test_piston1)
        r_max = round(test_groove_radius[0], 1)
        r_min = round(test_groove_radius[1], 1)

        self.assertEqual(r_max, 0.8), 'Class Piston def calculate_groove_radius do not ' \
                                      'perform calculation for piston groove r max properly'
        self.assertEqual(r_min, 0.4), 'Class Piston def calculate_groove_radius do not ' \
                                      'perform calculation for piston groove r min properly'

    def test_calculate_groove_area(self):
        test_length = 10
        test_width = 20
        test_area = Piston.calculate_groove_area(test_length, test_width)
        self.assertEqual(test_area, 200), 'Class Piston def calculate_groove_area do not ' \
                                          'perform calculation for piston area properly'


if __name__ == '__main__':
    unittest.main()
