from collections.abc import MutableMapping, Sequence
import logging
import math
# for pdf printing
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.lib.units import cm
# for plotting
import matplotlib.pyplot as plt
import pandas as pd
# for printing table with results
from prettytable import PrettyTable
# import some calculations from limit and fits calculator
from limits_and_fits_calculator import Hole, Shaft

# global variable to be plotted; units in [bar]
pressure = 250  # default pressure input unit is [bar]

#  credit to https://coralogix.com/log-analytics-blog/python-logging-best-practices-tips/
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s',
                    filename='myapp.log',
                    filemode='w')


class Pressure:
    def __init__(self, pressure_input=None):
        self.pressure = pressure_input

    def __add__(self, other):
        total_pressure = self.pressure + other.pressure
        total_pressure_psi = round((total_pressure * 14.503773773), 2)
        total_pressure_nmm2 = round((total_pressure * 0.1), 2)
        return f'{total_pressure} [bar] is {total_pressure_psi} [psi] or {total_pressure_nmm2} [N/mm2]'


class PrintingReport:
    def __init__(self, study_name, oring, bore, piston):
        self.study_name = study_name
        self.oring = oring
        self.bore = bore
        self.piston = piston

    def __str__(self):
        def my_generator():  # for fun to add split lines in printing process
            n = '-------------------------------------------------'
            yield n

            n = '-------------------------------------------------'
            yield n

            n = '***************************** INPUTS ************************'
            yield n

            n = '*************************************************************'
            yield n

            n = '*************************************************************'
            yield n

            n = '***************************** RESULTS ***********************'
            yield n

        x = my_generator()

        return f'\n{self.study_name} - Report File\n{next(x)}\nWorking pressure for our ' \
               f'application is {pressure} [bar]\n{next(x)}' \
               f'\n{next(x)}{str(self.oring)}\n\n{next(x)}{str(self.bore)}' \
               f'\n{next(x)}\n{self.piston}\n\n{next(x)}\n'


class ORing(MutableMapping):

    def __init__(self, code, characteristics):
        self.code = code
        self.characteristics = characteristics
        self.oring = {self.code: self.characteristics}
        if len(characteristics) < 4:
            raise KeyError(f'Please add all O-ring characteristics')
        logging.info(f'Creating an instance of ORing ISO 3601-1 B with {self.code} code')

    def __iter__(self):
        return self.oring

    def __getitem__(self, item):
        return self.oring[item]

    def __len__(self):
        return len(self.oring)

    def __setitem__(self, key, value):
        self.characteristics[key] = value

    def __delitem__(self, key):
        del self.characteristics[key]

    def keys(self):
        return self.oring.keys()

    def values(self):
        return self.oring.values()

    def items(self):
        return self.oring.items()

    def inner_diam(self):
        inner_diameter = self.characteristics.get('inner_diam Ød1', None)
        inner_diam_tol = self.characteristics.get('inner_diam_tol ±', None)
        d1_max = inner_diameter + inner_diam_tol
        d1_min = inner_diameter - inner_diam_tol
        return d1_max, d1_min

    def cross_section(self):
        section = self.characteristics.get('section Ød2', None)
        section_tol = self.characteristics.get('section_tol ±', None)
        d2_max = section + section_tol
        d2_min = section - section_tol
        return d2_max, d2_min

    # calculate MIN/ MAX circle area
    def dancilus(self):
        section = self.characteristics.get('section Ød2', None)
        section_tol = self.characteristics.get('section_tol ±', None)
        d2_max = section + section_tol
        d2_min = section - section_tol
        oring_csa_min = math.pi * (d2_min / 2) ** 2
        oring_csa_max = math.pi * (d2_max / 2) ** 2
        return oring_csa_max, oring_csa_min

    @classmethod  # general way to calculate circle area
    def circle_area(cls, diameter):
        circle_area = math.pi * (diameter / 2) ** 2
        return circle_area

    def __str__(self):
        print_oring = ''
        for index, charact in enumerate(self.characteristics, start=1):
            print_oring += f'\n {index}. {charact} : {self.characteristics[charact]}'
        # return f'\n{"*" * 20} INPUTS  {"*" * 40}\n\nCharacteristics for {self.code} O-ring are:\n{print_oring}'
        return f'\n\nCharacteristics for {self.code} O-ring are:\n{print_oring}'

    def __repr__(self):
        print_oring = ''
        for index, charact in enumerate(self.characteristics, start=1):
            print_oring += f'\n {index}. {charact} : {self.characteristics[charact]}'
        return f'\n{"*" * 61}\nCharacteristics for {self.code} O-ring are:\n{print_oring}'


class Bore(Hole):
    def __init__(self, nominal_diameter, tolerance):
        super().__init__(nominal_diameter, tolerance)
        if nominal_diameter < 3:
            raise Exception(f'Bore diameter cannot be so smaller; should be at least 3[mm]')
        self.nominal_diameter = nominal_diameter
        self.tolerance = tolerance
        logging.info(f'Creating an instance of Bore with Ø{nominal_diameter} and {tolerance} tolerance class')

    def __str__(self):
        return super().__str__()

    def __repr__(self):
        return f'\nBore internal diameter Ød4 -  {self.nominal_diameter}\
        n with {self.tolerance} tolerance'


class Piston(Shaft):

    def __init__(self, piston_characteristics=None, piston_diameter=None,
                 piston_diam_tol=None, groove_diameter=None, groove_diam_tol=None,
                 groove_width=None, groove_radius=None):
        super().__init__(piston_diameter, piston_diam_tol, groove_diameter, groove_diam_tol)
        if len(piston_characteristics) < 6:
            raise KeyError(f'Please add all Piston characteristics')
        self.groove_width = groove_width
        self.groove_radius = groove_radius
        self.piston_characteristics = piston_characteristics
        self.piston_diameter = self.piston_characteristics['piston diameter Ød9']
        self.piston_diam_tol = self.piston_characteristics['Ød9 tol']
        self.groove_diameter = self.piston_characteristics['groove Ød3']
        self.groove_diam_tol = self.piston_characteristics['Ød3 tol']
        self.groove_width = self.piston_characteristics['groove width b']
        self.groove_radius = self.piston_characteristics['groove radius r']
        logging.info(f'Creating an instance of Piston with  Ød9 = {self.piston_diameter}')

    def __iter__(self):
        return self.piston_characteristics

    def __getitem__(self, item):
        return self.piston_characteristics[item]

    def __len__(self):
        return len(self.piston_characteristics)

    def calculate_groove_width(self):
        groove_width = self.piston_characteristics.get('groove width b', None)
        b_max = groove_width + 0.2
        b_min = groove_width - 0
        return b_max, b_min

    def calculate_groove_radius(self):
        groove_radius = self.piston_characteristics.get('groove radius r', None)
        r_max = groove_radius + 0.2
        r_min = groove_radius - 0.2
        return r_max, r_min

    @classmethod  # general way to calculate rectangle area
    def calculate_groove_area(cls, length, width):
        return length * width

    def __str__(self):
        print_piston = ''
        for index, charact in enumerate(self.piston_characteristics, start=1):
            print_piston += f'\n {index}. {charact} : {self.piston_characteristics[charact]}'
        return f'\nPiston dimensions are:\n{print_piston}'
        # return f' none'

    def __repr__(self):
        print_piston = ''
        for index, charact in enumerate(self.piston_characteristics, start=1):
            print_piston += f'\n {index}. {charact} : {self.piston_characteristics[charact]}'
        return f'\n{"*" * 61}\nPiston dimensions are:\n{print_piston}'


# combine all objects previously created into study and perform calculations
class OringStudy(PrintingReport):
    def __init__(self, name, oring, bore, piston):
        super().__init__(name, oring, bore, piston)
        self.name = name
        self.oring = oring
        self.bore = bore
        self.piston = piston
        self.study = [name, [oring, bore, piston]]
        self.oring_code = oring.code
        self.d1 = oring.inner_diam()
        self.d2 = oring.cross_section()
        self.oring_csa_min = oring.dancilus()
        self.oring_csa_max = oring.dancilus()
        self.d4 = bore.calculate_diameters_bore()
        self.d9 = piston.calculate_diameter_piston()
        self.d3 = piston.calculate_diameter_groove()
        self.b = piston.calculate_groove_width()
        self.r = piston.calculate_groove_radius()
        logging.info(f'\n\nCreating an instance of OringStudy with name '
                     f'{self.name}, \n{self.oring}, \n{self.bore}, \n{self.piston} ')

    def __iter__(self):
        return iter(self.study)

    def __getitem__(self, name):
        return self.study[name]

    def __delitem__(self, name):
        del self.study[name]

    def __len__(self):
        return len(self.study)

    def __str__(self):
        global pressure
        text_to_print = PrintingReport.__str__(self)
        d1_min = self.d1[1]
        d1_max = self.d1[0]
        d2_min = self.d2[1]
        d2_max = self.d2[0]
        d4_min = self.d4[1]
        d4_max = self.d4[0]
        d9_min = self.d9[1]
        d9_max = self.d9[0]
        d3_min = self.d3[1]
        d3_max = self.d3[0]
        b_min = self.b[1]
        b_max = self.b[0]
        oring_csa_min = self.oring_csa_min[1]
        oring_csa_max = self.oring_csa_max[0]

        #  t Depth + gap - Concentric
        t_min = (d4_min - d3_max) / 2
        t_max = (d4_max - d3_min) / 2
        #  s gap
        s_min = (d4_min - d9_max) / 2
        s_max = (d4_max - d9_min) / 2
        #  t Depth + gap - Eccentric
        t_min_ecc = t_min - (s_min * 2)
        t_max_ecc = t_max + s_max
        # s gap ecc
        s_gap_ecc = d4_max - d9_min
        #  stretch inner diameter of O-ring in assembly operation
        sic_min = 100 * (d3_min - d1_max) / d1_max
        sic_max = 100 * (d3_max - d1_min) / d1_min
        # Cross Section Reduction Observed because of stretching inner diam - in [%]
        cs_min = ''
        if sic_min <= 3:
            cs_min = -0.005 + 1.19 * sic_min - 0.19 * (sic_min ** 2) - 0.001 * (sic_min ** 3) + 0.008 * (sic_min ** 4)
        else:
            if sic_min <= 25:
                cs_min = 0.56 + 0.59 * sic_min - 0.0046 * (sic_min ** 2)
            else:
                print('Warning !!!')
        cs_max = ''
        if sic_max <= 3:
            cs_max = -0.005 + 1.19 * sic_max - 0.19 * (sic_max ** 2) - 0.001 * (sic_max ** 3) + 0.008 * (sic_max ** 4)
        else:
            if sic_max <= 25:
                cs_max = 0.56 + 0.59 * sic_max - 0.0046 * (sic_max ** 2)
            else:
                print('Warning !!!')
        # Cross Section diameter based on stretching - in [mm]
        css_diam_min = d2_min - ((cs_max * d2_min) / 100)
        css_diam_max = d2_max - ((cs_min * d2_max) / 100)
        # Compression of OR ød2 - in [%]
        comp_min = 100 * (css_diam_min - t_max) / css_diam_min
        comp_max = 100 * (css_diam_max - t_min) / css_diam_max
        # gland fill
        gland_csa_min = b_min * (t_min_ecc - s_gap_ecc)
        gland_csa_max = b_max * (t_max_ecc - s_max)
        gland_fill_min = 100 * (oring_csa_min / gland_csa_max)
        gland_fill_max = 100 * (oring_csa_max / gland_csa_min)

        results_list_description = ['t: Depth + gap          ', 's: gap                  ', 'Stretch of OR inner-ø   ',
                                    'CS Reduction Observed   ', 'CS Stretch Observed     ', 'Compression of OR ød2   ',
                                    'O-ring CSA              ', 'Gland CSA               ', 'Gland fill              ']
        results_list_min = [t_min, s_min, sic_min, cs_min, css_diam_min, comp_min,
                            oring_csa_min, gland_csa_min, gland_fill_min]

        results_list_max = [t_max, s_max, sic_max, cs_max, css_diam_max, comp_max,
                            oring_csa_max, gland_csa_max, gland_fill_max]

        units_list = ['[mm]', '[mm]', '[%]', '[%]', '[mm]', '[%]', '[mm^2]',
                      '[mm^2]', '[%]']

        recomm_values_list = ['', '', '       0 ... 6', '', '', '       13 ... 30', '', '', '       60 ... 90']

        final_list = zip(results_list_description, results_list_min, results_list_max,
                         units_list, recomm_values_list)

        # printing results
        rows = ''
        for index, item in enumerate(final_list, start=1):
            rows += f'\n{index}. {item[0]} {"{:8.2f}".format(item[1])} {"{:8.2f}".format(item[2])} {item[3]} {item[4]}'

        table1 = PrettyTable(['Description', 'MIN', 'MAX', 'Units', 'Recommended'])
        for x in range(0, 9):
            table1.add_row([results_list_description[x], "{:8.2f}".format(results_list_min[x]),
                            "{:8.2f}".format(results_list_max[x]), units_list[x], recomm_values_list[x]])
        # to use in pdf report
        print_report = f'\n{text_to_print}' \
                       f'\n{" " * 38}    Concentric' \
                       f'\n{" " * 38}  MIN        MAX                      Recomm.' \
                       f'\n{rows}'

        # to use in txt report
        print_report2 = f'\n{text_to_print}' \
                        f'\n{table1}'

        # print report text file
        with open("report.txt", "w") as text_file:
            text_file.write("{0}".format(print_report2))

        # plot
        df = pd.ExcelFile('external resources.xls').parse('plot')
        x_70 = df['x1'].tolist()
        y_70 = df['y1'].tolist()
        x_80 = df['x2'].tolist()
        y_80 = df['y2'].tolist()
        x_90 = df['x3'].tolist()
        y_90 = df['y3'].tolist()
        plt.figure('O-ring Extrusion Chart')
        plt.plot(x_70, y_70, label="90 shore")
        plt.plot(x_80, y_80, label="80 shore")
        plt.plot(x_90, y_90, label="70 shore")
        plt.scatter(s_min, pressure, label="risk extrusion min gap")
        plt.scatter(s_max, pressure, label="risk extrusion max gap")
        plt.xlabel('Total diametrical clearance [mm]')
        plt.ylabel('Fluid pressure [bar]')
        plt.title('O-rings extrusion chart')
        plt.legend()
        # plt.show()
        plt.pause(0.5)
        plt.savefig('plot', dpi=61)

        #   print report pdf file
        pdfmetrics.registerFont(TTFont('Arial', 'Arial.ttf'))
        schematic = ImageReader('o-ring small 2.png')
        plot = ImageReader('plot.png')
        cross_section_image = ImageReader('cross section.png')
        # canvas = Canvas(f'{self.oring_code}.pdf', pagesize=A4)
        canvas = Canvas(f'report.pdf', pagesize=A4)

        canvas.setFont('Arial', 10)
        canvas.drawImage(schematic, 350, 320, mask='auto')
        canvas.drawImage(plot, 230, 10, mask='auto')
        canvas.drawImage(cross_section_image, 5, 10, mask='auto')
        text_object = canvas.beginText(0.5 * cm, 29.7 * cm - 0.1 * cm)
        for line in print_report.splitlines(False):
            text_object.textLine(line.rstrip())

        canvas.drawText(text_object)
        canvas.showPage()
        canvas.save()

        return f'{text_to_print}\n\n{table1}'

    def __repr__(self):
        return f'{self.name}'


#  list of studies (multiple OringStudy)
class ProductStudies(Sequence):

    def __init__(self, *args):
        self.study = list(args)

    def __getitem__(self, item):
        return self.study[item]

    def __delitem__(self, item):
        del self.study[item]

    def __len__(self):
        return len(self.study)

    def __iter__(self):
        return iter(self.study)

    def append(self, item):
        self.study.append(item)

    def pop(self):
        return self.study.pop()

    def remove(self, item):
        self.study.remove(item)

    def __repr__(self):
        return f'{[study.name for study in self.study]}'

    def __str__(self):
        list_studies = [study.name for study in self.study]
        print_studies = ''
        for index, study in enumerate(list_studies, start=1):
            print_studies += f'\n {index}. {study}'
        return f'\nList of performed studies are:\n{print_studies}'

